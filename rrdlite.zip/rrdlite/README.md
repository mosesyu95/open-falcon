# Go (golang) for rrdtool(1.4.9)

一个轻量级的rrdtool工具包，线程安全，解除librrd依赖,只提供create,update,fetch,info

## Installing

    go get github.com/yubo/rrdlite


## Example 
See [rrd_test.go](https://github.com/yubo/rrdlite/blob/master/rrd_test.go) for an example of using this package.
